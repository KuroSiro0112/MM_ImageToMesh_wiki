// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> issue149("issue149", 2, 1e-14, 0.000001, {
    {{1888,5504},{1872,5504},{1872,5536},{1856,5536},{1856,5520},{1840,5520},{1840,5504},{1856,5504},{1856,5520},{1872,5520},{1872,5504},{1888,5504}},
    {{1856,5520},{1856,5536},{1872,5536},{1872,5520}},
});

}
}
