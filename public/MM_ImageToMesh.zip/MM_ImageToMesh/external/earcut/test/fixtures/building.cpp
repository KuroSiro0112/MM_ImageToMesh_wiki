// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> building("building", 13, 1e-14, 0.000001, {
    {{661,112},{661,96},{666,96},{666,87},{743,87},{771,87},{771,114},{750,114},{750,113},{742,113},{742,106},{710,106},{710,113},{666,113},{666,112}},
});

}
}
