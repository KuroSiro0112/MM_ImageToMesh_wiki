// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> touching3("touching3", 15, 1e-14, 0.000001, {
    {{1241,887},{1257,891},{1248,904},{1232,911},{1212,911},{1207,911},{1209,900},{1219,898},{1225,907},{1241,887}},
    {{1212,902},{1212,911},{1219,909},{1212,902}},
    {{1248,891},{1239,896},{1246,898},{1248,891}},
});

}
}
