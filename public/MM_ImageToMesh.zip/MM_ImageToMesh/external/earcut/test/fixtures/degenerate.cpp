// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> degenerate("degenerate", 0, 1e-14, 0.000001, {
    {{100,100},{100,100},{200,100},{200,200},{200,100},{0,100}},
});

}
}
