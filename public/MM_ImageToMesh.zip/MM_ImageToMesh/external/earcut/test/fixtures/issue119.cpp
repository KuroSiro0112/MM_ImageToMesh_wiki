// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> issue119("issue119", 18, 1e-14, 0.04, {
    {{2,12},{2,20},{25,20},{25,12}},
    {{7,18},{7,15},{5,15}},
    {{19,18},{19,17},{17,17}},
    {{19,17},{21,17},{19,16}},
    {{7,15},{9,15},{7,13}},
});

}
}
