// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> issue135("issue135", 1, Infinity, Infinity, {
    {{1,2},{2,2},{1,2},{1,1}},
    {{4,1},{5,1},{3,2},{4,2}},
});

}
}
