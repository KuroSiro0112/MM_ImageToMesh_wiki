// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> touching4("touching4", 20, 1e-14, 0.06, {
    {{11,10},{0,10},{0,0},{11,0}},
    {{7,6},{7,9},{10,9}},
    {{7,5},{10,2},{10,5}},
    {{6,9},{1,4},{1,9}},
    {{1,1},{1,4},{4,1}},
});

}
}
