// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> shared_points("shared_points", 4, 1e-14, 0.000001, {
    {{4136,1016},{4112,1016},{4104,976},{4136,1016},{4144,984},{4104,976},{4144,968},{4144,984},{4168,992},{4152,1064}},
});

}
}
