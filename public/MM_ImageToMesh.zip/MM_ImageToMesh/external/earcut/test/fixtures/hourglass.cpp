// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> hourglass("hourglass", 2, 1e-14, 0.000001, {
    {{7,18},{7,15},{5,15},{7,13},{7,15},{17,17}},
});

}
}
