﻿// -*- coding: utf-8 -*-
// mm_itm_core.cpp  (2025-07-03 rev-F5)  Earcut + Triangle + Poisson
//
// ● extra を必ず「最後」に push（segPush 後）
// ● seg 最大インデックスと頂点数を必ず表示＆検証（範囲外なら例外）
// ● 退化リング閾値 1e-3、Triangle オプション "pQBeyj"
// ● tri_mesh_debug を公開（Python から直接呼べる）
// ------------------------------------------------------------------

#define _USE_MATH_DEFINES
#include <cmath>
#include <cstring>
#include <random>
#include <vector>
#include <array>
#include <algorithm>
#include <numeric>
#include <stdexcept>
#include <string>
#include <limits>
#include <iostream>

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/numpy.h>
#include <opencv2/opencv.hpp>
#include <mapbox/earcut.hpp>

namespace py = pybind11;
using namespace pybind11::literals;

/* ---- Triangle ----------------------------------------------------- */
#pragma push_macro("REAL")
#pragma push_macro("VOID")
#undef  REAL
#undef  VOID
#define REAL  double
#define VOID  void
extern "C" {
#   include "external/triangle/triangle.h"
}
extern "C" void trifree(void*);
#pragma pop_macro("VOID")
#pragma pop_macro("REAL")

/* ---- 定数 --------------------------------------------------------- */
constexpr int     _SS               = 1;
constexpr double  _MIN_ISLAND_RATIO = 5e-4;
constexpr int64_t MAX_PIXELS        = 4096LL * 4096LL;

/* =================================================================== */
/* PNG → 2値マスク                                                     */
static void load_mask(const std::string& path,int margin,
                      cv::Mat& mask,int& w,int& h,float& scale)
{
    cv::Mat img=cv::imread(path,cv::IMREAD_UNCHANGED);
    if(img.empty())
        throw std::runtime_error(u8"PNG を指定してください");

    h=img.rows; w=img.cols;
    if(int64_t(w)*h>MAX_PIXELS)
        throw std::runtime_error(u8"画像が大きすぎます");

    cv::Mat alpha;
    if(img.channels()>=4)
        cv::extractChannel(img,alpha,3);
    else
        alpha=cv::Mat(h,w,CV_8UC1,cv::Scalar(255));

    if(margin>0){
        cv::copyMakeBorder(alpha,alpha,margin,margin,margin,margin,
                           cv::BORDER_CONSTANT,cv::Scalar(0));
        w+=margin*2; h+=margin*2;
    }
    cv::threshold(alpha,mask,0,255,cv::THRESH_BINARY);
    scale=1.f;
}

/* ---------- 幾何ユーティリティ ---------------------------------- */
static double signed_area(const std::vector<cv::Point2f>& v)
{
    double a=0;
    for(size_t i=0;i<v.size();++i){
        const auto& p0=v[i];
        const auto& p1=v[(i+1)%v.size()];
        a+=p0.x*p1.y - p0.y*p1.x;
    }
    return 0.5*a;
}

static std::vector<cv::Point2f> clean_loop(std::vector<cv::Point2f> v)
{
    v.erase(std::unique(v.begin(),v.end(),
        [](auto&a,auto&b){return cv::norm(a-b)<1e-6;}),v.end());
    if(v.size()>=2 && cv::norm(v.front()-v.back())<1e-6) v.pop_back();
    if(v.size()<3){
        float minx=v[0].x,maxx=v[0].x,miny=v[0].y,maxy=v[0].y;
        for(auto&p:v){
            minx=std::min(minx,p.x); maxx=std::max(maxx,p.x);
            miny=std::min(miny,p.y); maxy=std::max(maxy,p.y);
        }
        float pad=1.f;
        return {{minx-pad,miny-pad},{maxx+pad,miny-pad},
                {maxx+pad,maxy+pad},{minx-pad,maxy+pad}};
    }
    return v;
}

static bool valid_ring(const std::vector<cv::Point2f>& r)
{
    return r.size()>=3 && std::fabs(signed_area(r))>1e-3;
}

/* ---------- Poisson Disk ---------------------------------------- */
static std::vector<cv::Point2f> poisson_disk(int w,int h,float r,int k=30)
{
    const float cell=r/std::sqrt(2.f);
    const int gw=int(w/cell)+1, gh=int(h/cell)+1;
    std::vector<cv::Point2f> grid(gw*gh,{-9999.f,-9999.f});
    std::vector<cv::Point2f> pts,active;
    std::mt19937 rng{std::random_device{}()};
    std::uniform_real_distribution<float> U(0.f,1.f);

    auto add=[&](cv::Point2f p){
        pts.push_back(p); active.push_back(p);
        grid[int(p.x/cell)+int(p.y/cell)*gw]=p;
    };
    add({U(rng)*w,U(rng)*h});

    while(!active.empty()){
        size_t idx=std::uniform_int_distribution<size_t>(0,active.size()-1)(rng);
        cv::Point2f o=active[idx]; bool found=false;
        for(int t=0;t<k;++t){
            float ang=U(rng)*float(M_PI*2), rad=r*(1+U(rng));
            cv::Point2f p=o+cv::Point2f(std::cos(ang),std::sin(ang))*rad;
            if(p.x<0||p.y<0||p.x>=w||p.y>=h) continue;
            int gx=int(p.x/cell), gy=int(p.y/cell); bool ok=true;
            for(int ix=std::max(gx-2,0); ix<=std::min(gx+2,gw-1)&&ok;++ix)
                for(int iy=std::max(gy-2,0); iy<=std::min(gy+2,gh-1)&&ok;++iy){
                    cv::Point2f q=grid[ix+iy*gw]; if(q.x<0) continue;
                    if(cv::norm(p-q)<r){ ok=false; break; }
                }
            if(ok){ add(p); found=true; break; }
        }
        if(!found) active.erase(active.begin()+idx);
    }
    return pts;
}

/* ---------- split_loops ----------------------------------------- */
static void split_loops(const std::vector<cv::Point2f>& verts,
                        const std::vector<uint32_t>& holes_idx,
                        std::vector<cv::Point2f>& outer,
                        std::vector<std::vector<cv::Point2f>>& holes)
{
    if(holes_idx.empty()){ outer=verts; return; }
    uint32_t start=0;
    for(size_t hi=0; hi<=holes_idx.size(); ++hi){
        uint32_t end=(hi<holes_idx.size())?holes_idx[hi]:(uint32_t)verts.size();
        std::vector<cv::Point2f> ring(verts.begin()+start,verts.begin()+end);
        if(hi==0) outer=std::move(ring);
        else      holes.push_back(std::move(ring));
        start=end;
    }
}


/* ================================================================= */
/* ----------------- Triangle ラッパ (tri_mesh) -------------------- */
static py::dict tri_mesh(const std::vector<cv::Point2f>& outer,
    const std::vector<std::vector<cv::Point2f>>& holes,
    const std::vector<cv::Point2f>& extra)
{
/* ---------- 入力検証 ---------- */
if (!valid_ring(outer))
throw std::runtime_error("outer ring degenerate");

std::vector<std::vector<cv::Point2f>> holes_ok;
for (auto& h : holes)
if (valid_ring(h)) holes_ok.push_back(h);

/* ---------- Point / Segment 準備 ---------- */
std::vector<double> pl;                         // pointlist
auto push = [&](const std::vector<cv::Point2f>& v) {
for (auto& p : v) { pl.push_back(p.x); pl.push_back(p.y); }
};
push(outer);
for (auto& h : holes_ok) push(h);

std::vector<int> seg;
int off = 0;
auto segPush = [&](const std::vector<cv::Point2f>& ring) {
const int n = int(ring.size());
for (int i = 0; i < n; ++i) {
seg.push_back(off + i);
seg.push_back(off + (i + 1) % n);
}
off += n;
};
segPush(outer);
for (auto& h : holes_ok) segPush(h);

push(extra);                                    // extra point は最後

/* ---------- 整合チェック ---------- */
const int pointcount = int(pl.size() / 2);
const int maxIdx     = *std::max_element(seg.begin(), seg.end());
if (maxIdx >= pointcount)
throw std::runtime_error("seg index exceeds pointlist");

/* ---------- Hole 重心 ---------- */
std::vector<double> holes_xy;                   // x0,y0,x1,y1…
for (auto& h : holes_ok) {
double cx = 0, cy = 0;
for (auto& p : h) { cx += p.x; cy += p.y; }
cx /= h.size(); cy /= h.size();
holes_xy.push_back(cx); holes_xy.push_back(cy);
}

/* ---------- Triangle 呼び出し ---------- */
triangulateio in{}, out{};
in.pointlist        = pl.data();
in.numberofpoints   = pointcount;
in.segmentlist      = seg.data();
in.numberofsegments = int(seg.size() / 2);
if (!holes_xy.empty()) {
in.holelist      = holes_xy.data();
in.numberofholes = int(holes_xy.size() / 2);
}

/* ‘Y’ で境界分割禁止 / ‘B’ で boundary marker 抑制 */
triangulate((char*)"pzQBYej", &in, &out, nullptr);

/* ---------- シルエット外ポリゴン除去 ---------- */
std::vector<int> keep;
keep.reserve(out.numberoftriangles * 3);

auto inside = [&](const cv::Point2f& P) -> bool {
if (cv::pointPolygonTest(outer, P, false) < 0)
return false;
for (auto& h : holes_ok)
if (cv::pointPolygonTest(h, P, false) >= 0)
return false;
return true;
};

for (int t = 0; t < out.numberoftriangles; ++t) {
int i0 = out.trianglelist[t * 3 + 0];
int i1 = out.trianglelist[t * 3 + 1];
int i2 = out.trianglelist[t * 3 + 2];
cv::Point2f c(
float(out.pointlist[i0 * 2 + 0] + out.pointlist[i1 * 2 + 0] + out.pointlist[i2 * 2 + 0]) / 3.f,
float(out.pointlist[i0 * 2 + 1] + out.pointlist[i1 * 2 + 1] + out.pointlist[i2 * 2 + 1]) / 3.f
);

if (inside(c)) {
keep.push_back(i0);
keep.push_back(i1);
keep.push_back(i2);
}
}

/* ---------- Python へコピー ---------- */
py::array_t<double> pyV({ out.numberofpoints, 2 });
std::memcpy(pyV.mutable_data(), out.pointlist,
sizeof(double) * out.numberofpoints * 2);

py::array_t<int> pyI({ int(keep.size()) });
if (!keep.empty())
std::memcpy(pyI.mutable_data(), keep.data(),
sizeof(int) * keep.size());

/* ---------- メモリ解放（所有権のあるものだけ） ---------- */
auto free_if = [&](void* p) { if (p) trifree(p); };
free_if(out.pointlist);
free_if(out.trianglelist);
free_if(out.segmentlist);
free_if(out.segmentmarkerlist);
free_if(out.pointmarkerlist);              // holelist は in.* のコピー
free_if(out.edgelist);
free_if(out.edgemarkerlist);
free_if(out.neighborlist);

/* ---------- 結果返却 ---------- */
return py::dict("v"_a = pyV, "idx"_a = pyI);
}


/* ============================================================= */
/* 追加ヘルパー：外周 inside && 各穴 outside を判定 -------------- */
static inline bool inside_polygon_holes(
    const cv::Point2f& p,
    const std::vector<cv::Point2f>& outer,
    const std::vector<std::vector<cv::Point2f>>& holes )
{
// 外周ポリゴンの内側に無いなら false
if (cv::pointPolygonTest(outer, p, false) < 0)
    return false;

// いずれかの穴ポリゴンの内側なら false
for (const auto& h : holes)
    if (cv::pointPolygonTest(h, p, false) >= 0)
        return false;

return true;    // 外周内かつ穴外 → true
}
/* ============================================================= */

/* =================================================================== */
/* islands ------------------------------------------------------------ */
py::dict islands(const std::string& path,float eps,int margin)
{
    cv::Mat mask; int w,h; float scale;
    load_mask(path,margin,mask,w,h,scale);

    std::vector<std::vector<cv::Point>> ctrs;
    cv::findContours(mask,ctrs,cv::RETR_EXTERNAL,cv::CHAIN_APPROX_NONE);

    std::vector<std::vector<float>> loops;
    for(auto& c:ctrs){
        if(cv::contourArea(c)<3.0) continue;

        std::vector<cv::Point> apx;
        cv::approxPolyDP(c,apx,eps*_SS,true);

        std::vector<cv::Point2f> v;
        for(auto&p:apx) v.emplace_back(p.x/float(_SS),p.y/float(_SS));
        v=clean_loop(std::move(v));
        if(signed_area(v)>0) std::reverse(v.begin(),v.end());

        std::vector<float> flat; flat.reserve(v.size()*2);
        for(auto&p:v){ flat.push_back(p.x); flat.push_back(p.y); }
        loops.push_back(std::move(flat));
    }
    return py::dict("loops"_a=loops,"w"_a=w,"h"_a=h,"scale"_a=scale);
}

/* =================================================================== */
/* triangulate_png ---------------------------------------------------- */
py::dict triangulate_png(const std::string& path,float eps,int margin,float)
{
    cv::Mat mask; int w,h; float scale;
    load_mask(path,margin,mask,w,h,scale);

    std::vector<std::vector<cv::Point>> ctrs;
    std::vector<cv::Vec4i> hier;
    cv::findContours(mask,ctrs,hier,cv::RETR_CCOMP,cv::CHAIN_APPROX_NONE);
    if(ctrs.empty()||hier.empty())
        throw std::runtime_error(u8"不透明領域が見つかりません");

    cv::Mat nz; cv::findNonZero(mask,nz);
    int64_t bbox=int64_t(nz.at<cv::Point>(nz.total()-1).x - nz.at<cv::Point>(0).x +1)*
                 int64_t(nz.at<cv::Point>(nz.total()-1).y - nz.at<cv::Point>(0).y +1);
    double min_area=double(bbox)*_MIN_ISLAND_RATIO;

    struct G{std::vector<cv::Point2f> v; std::vector<uint32_t> holes;};
    std::vector<G> groups;

    for(size_t i=0;i<ctrs.size();++i){
        if(hier[i][3]!=-1) continue;
        if(cv::contourArea(ctrs[i])<min_area) continue;

        G g; std::vector<cv::Point> apx;
        cv::approxPolyDP(ctrs[i],apx,eps*_SS,true);
        for(auto&p:apx) g.v.emplace_back(p.x/float(_SS),p.y/float(_SS));
        g.v=clean_loop(std::move(g.v));
        if(signed_area(g.v)>0) std::reverse(g.v.begin(),g.v.end());
        uint32_t off=(uint32_t)g.v.size();

        int ch=hier[i][2];
        while(ch!=-1){
            if(cv::contourArea(ctrs[ch])>=min_area){
                std::vector<cv::Point> apxH;
                cv::approxPolyDP(ctrs[ch],apxH,eps*_SS,true);
                std::vector<cv::Point2f> hv;
                for(auto&p:apxH) hv.emplace_back(p.x/float(_SS),p.y/float(_SS));
                hv=clean_loop(std::move(hv));
                if(signed_area(hv)<0) std::reverse(hv.begin(),hv.end());
                g.holes.push_back(off);
                g.v.insert(g.v.end(),hv.begin(),hv.end());
                off+=uint32_t(hv.size());
            }
            ch=hier[ch][0];
        }
        groups.push_back(std::move(g));
    }

    using Ring=std::vector<std::array<double,2>>;
    std::vector<py::dict> py_groups;
    for(auto&g:groups){
        std::vector<Ring> poly;
        uint32_t start=0;
        for(size_t hi=0;hi<=g.holes.size();++hi){
            uint32_t end=(hi<g.holes.size())?g.holes[hi]:(uint32_t)g.v.size();
            Ring ring;
            for(uint32_t i=start;i<end;++i)
                ring.push_back({g.v[i].x,g.v[i].y});
            poly.push_back(std::move(ring));
            start=end;
        }
        std::vector<uint32_t> idx=mapbox::earcut<uint32_t>(poly);

        std::vector<double> flat; flat.reserve(g.v.size()*2);
        for(auto&p:g.v){ flat.push_back(p.x); flat.push_back(p.y); }

        py_groups.push_back(py::dict("v"_a=flat,"idx"_a=idx));
    }
    return py::dict("groups"_a=py_groups,"w"_a=w,"h"_a=h,"scale"_a=scale);
}



/* =================================================================== */
/* poisson_png -------------------------------------------------------- */
py::dict poisson_png(const std::string& path,
    float eps, int margin, int rpx)
{
/* 0) マスク読込 -------------------------------------------------- */
cv::Mat mask; int w, h; float scale;
load_mask(path, margin, mask, w, h, scale);

/* 1) 外周＋穴リング抽出 ----------------------------------------- */
std::vector<std::vector<cv::Point>> ctrs; std::vector<cv::Vec4i> hier;
cv::findContours(mask, ctrs, hier, cv::RETR_CCOMP, cv::CHAIN_APPROX_NONE);
if (ctrs.empty()) throw std::runtime_error("不透明領域が見つかりません");

size_t outerIdx = 0; double maxA = 0.0;
for (size_t i = 0; i < ctrs.size(); ++i) {
double a = std::fabs(cv::contourArea(ctrs[i]));
if (a > maxA) { maxA = a; outerIdx = i; }
}
std::vector<cv::Point2f> outer;
for (auto& p : ctrs[outerIdx]) outer.emplace_back(p.x, p.y);

std::vector<std::vector<cv::Point2f>> holes;
for (int ch = hier[outerIdx][2]; ch != -1; ch = hier[ch][0])
if (std::fabs(cv::contourArea(ctrs[ch])) > 1.0) {
std::vector<cv::Point2f> hv;
for (auto& p : ctrs[ch]) hv.emplace_back(p.x, p.y);
holes.push_back(std::move(hv));
}

/* 2) マージン後シルエット画像 → 距離変換 ------------------------ */
cv::Mat sil = cv::Mat::zeros(h * _SS, w * _SS, CV_8U);
auto to_i = [](const cv::Point2f& p){ return cv::Point(int(p.x * _SS), int(p.y * _SS)); };

{   std::vector<std::vector<cv::Point>> poly(1);
for (auto& p : outer) poly[0].push_back(to_i(p));
cv::fillPoly(sil, poly, 255);                      // 外周 255
}
for (auto& hring : holes){
std::vector<std::vector<cv::Point>> poly(1);
for (auto& p : hring) poly[0].push_back(to_i(p));
cv::fillPoly(sil, poly, 0);                        // 穴を 0
}

cv::Mat distf; cv::distanceTransform(sil, distf, cv::DIST_L2, 3);
const float SAFE = 1.5f * rpx * _SS;                   // 境界から 1.5rpx 以上

/* 3) Poisson 点生成（安全域のみ） ------------------------------ */
std::vector<cv::Point2f> pts; const float r2 = float(rpx) * rpx;
for (auto& p : poisson_disk(w, h, float(rpx))) {
if (distf.at<float>(int(p.y * _SS), int(p.x * _SS)) < SAFE) continue;
if (!inside_polygon_holes(p, outer, holes))         continue;

bool ok = true;
for (auto& q : pts) {
float dx = p.x - q.x, dy = p.y - q.y;
if (dx*dx + dy*dy < r2) { ok = false; break; }
}
if (ok) pts.push_back(p);
}

/* 4) 三角化 ----------------------------------------------------- */
py::dict res = tri_mesh(outer, holes, pts);
res["w"] = w; res["h"] = h; res["scale"] = scale;
return res;
}



/* =================================================================== */
PYBIND11_MODULE(mm_itm_core,m)
{
    m.doc()="MM_ImageToMesh C++ core (Earcut + Triangle + Poisson)";
    m.def("islands",         &islands        , "path"_a, "eps"_a, "margin"_a);
    m.def("triangulate_png", &triangulate_png, "path"_a, "eps"_a, "margin"_a, "maxA"_a);
    m.def("poisson_png",     &poisson_png    , "path"_a, "eps"_a, "margin"_a, "rpx"_a);

    /* デバッグ用：tri_mesh を直接呼び出す */
    m.def("tri_mesh_debug",  &tri_mesh       , "outer"_a, "holes"_a, "extra"_a);
}
