# -*- coding: utf-8 -*-
"""
MM_ImageToMesh v1.00
------------------------------------------------------------


#------------------------------------------------------------------------
# 起動コマンド（例）
import sys
import importlib
import os

# ツールを保存した場所を sys.path に追加してください
# import sys; sys.path.append(r"C:/Path/To/MM_ImageToMesh")

import MM_ImageToMesh
importlib.reload(MM_ImageToMesh)
MM_ImageToMesh.main()
#------------------------------------------------------------------------
"""

from __future__ import annotations
import sys, os

# ===== パス設定 (Importsの前に行う必要があります) ============================
# このファイルのディレクトリを取得
module_dir = os.path.dirname(os.path.abspath(__file__))
if module_dir not in sys.path:
    sys.path.insert(0, module_dir)

# 後方互換性のため script_path も定義しておく
script_path = module_dir

# libs ディレクトリをパスに追加
libs_dir = os.path.join(module_dir, "libs")
if os.path.exists(libs_dir):
    if libs_dir not in sys.path:
        sys.path.insert(0, libs_dir)
    # Windows (Python 3.8+) DLL読み込み対応
    if os.name == 'nt' and hasattr(os, 'add_dll_directory'):
        try:
            os.add_dll_directory(libs_dir)
        except Exception:
            pass
    # フォールバックとしてPATHにも追加
    os.environ['PATH'] = libs_dir + os.pathsep + os.environ.get('PATH', '')

import importlib, tempfile, types, webbrowser, gc
try:
    import numpy as np
except ImportError:
    print("Error: numpy not found. Please ensure numpy is installed or available in 'libs' directory.")
    np = None

try:
    import cv2
except ImportError:
    # cv2がlibsに見つからない、または読み込めない場合のフォールバック（警告など）
    # 通常はlibsにあるはずなので、パス設定が正しければここは通るはず
    print("Warning: cv2 not found. Image processing features may fail.")
    cv2 = None

try:
    from PySide2 import QtCore
except ImportError:
    try:
        from PySide6 import QtCore
    except ImportError:
        QtCore = None
        print("Warning: QtCore not found. UI responsiveness may be affected.")

import maya.cmds as cmds
import maya.OpenMaya as om
import maya.api.OpenMaya as om2
import maya.mel as mel

# ===== 0. 上限 ===========================================================
_MAX_VERTS = 60_000
_MAX_TRIS  = 120_000
def _check_size(vn: int, tn: int):
    if vn > _MAX_VERTS or tn > _MAX_TRIS:
        raise RuntimeError(f"メッシュが大き過ぎます "
                           f"(Verts:{vn}/{_MAX_VERTS}, Tris:{tn}/{_MAX_TRIS})")

# ===== 1. C++ コア =======================================================
try:
    import mm_itm_core; importlib.reload(mm_itm_core); _USE_CPP = True
except Exception:
    mm_itm_core = None; _USE_CPP = False

# ===== 2. Earcut / Triangle =============================================
try:
    import mapbox_earcut as _me
    if not hasattr(_me, "earcut") and hasattr(_me, "triangulate_float32"):
        _me.earcut = _me.triangulate_float32
except Exception:
    _me = None
def _wrap_pyearcut(mod: types.ModuleType):
    for n in ("triangulate_float32", "triangulate_uint32", "triangulate"):
        fn = getattr(mod, n, None)
        if fn:
            def _f(flat, holes, dim, _fn=fn):
                if np is None:
                    raise RuntimeError("numpy is required for earcut/triangle.")
                return _fn(flat, np.asarray(holes, np.uint32), dim).tolist()
            return _f
    return None
def load_earcut():
    try:
        import mapbox_earcut as m
        if hasattr(m, "earcut"):               return m.earcut
        if hasattr(m, "triangulate_float32"):  return m.triangulate_float32
    except Exception:
        pass
    try:
        mod  = importlib.import_module("earcut.pyearcut")
        fn   = _wrap_pyearcut(mod)  # type: ignore
        if fn: return fn
    except Exception:
        pass
    try:
        import earcut as e
        if hasattr(e, "earcut"): return e.earcut
    except Exception:
        pass
    return None
earcut = load_earcut()
try:
    import triangle as tr
except ImportError:
    tr = None

# ===== 3. 定数 ===========================================================
_SS               = 1
_MIN_ISLAND_RATIO = 5e-4
MAX_PIXELS        = 4096 * 4096

# ===== 4. triangulate_full ==============================================
def pslg(v, holes):
    segs = []
    rings = [0] + holes + [len(v)]
    for s, e in zip(rings[:-1], rings[1:]):
        idx = np.arange(s, e, dtype=np.int32)
        segs.extend(np.stack([idx, np.roll(idx, -1)], 1))
    d = {'vertices': v, 'segments': np.asarray(segs, np.int32)}
    if holes:
        d['holes'] = np.asarray([v[h].mean(0) for h in holes], np.float32)
    return d


# ================================================================
# 4. triangulate_full : 外周＋穴＋任意ポイントのフル三角化
# extra: 追加ポイント群（配列）。float値は不可。
def triangulate_full(out, holes, extra, rpx):
    loops = [out] + holes + ([extra] if extra.size else [])
    v = np.vstack(loops).astype(np.float32)

    holes_idx = []
    acc = len(out)
    for h in holes:
        holes_idx.append(acc)
        acc += len(h)

    # ---------- Triangle 優先 ------------------------------------
    if tr:
        try:
            segs = []
            off = 0
            for loop in [out] + holes:
                n = len(loop)
                idx_loop = np.arange(off, off + n, dtype=np.int32)
                segs.extend(np.stack([idx_loop, np.roll(idx_loop, -1)], 1))
                off += n
            d = {'vertices': v, 'segments': np.asarray(segs, np.int32)}
            if holes:
                d['holes'] = np.asarray([h.mean(0) for h in holes], np.float32)
            tri = tr.triangulate(d, 'pQBY')
            if tri.get('triangles') is not None:
                return v, np.asarray(tri['triangles'].flatten(), np.int32)
        except Exception as e:
            print('# triangle failed → earcut fallback', e)

    # ---------- Earcut ルート ------------------------------------
    if earcut:
        try:
            idx = earcut(v.ravel().tolist(), holes_idx, 2)
            idx = np.asarray(idx, np.int32)

            # ----- シルエット外ポリゴン除去 ----------------------
            outer_loop = v[:len(out)]
            hole_loops = []
            offset = len(out)
            for h in holes:
                hole_loops.append(v[offset:offset+len(h)])
                offset += len(h)

            def _inside(P):
                if cv2.pointPolygonTest(outer_loop, P, False) < 0:
                    return False
                for hl in hole_loops:
                    if cv2.pointPolygonTest(hl, P, False) >= 0:
                        return False
                return True

            keep = []
            for i in range(0, len(idx), 3):
                i0, i1, i2 = idx[i:i+3]
                c = (v[i0] + v[i1] + v[i2]) / 3.0
                if _inside(tuple(c)):
                    keep.extend([i0, i1, i2])

            return v, np.asarray(keep, np.int32)
        except Exception as e:
            print('# earcut failed → NGON fallback', e)

    # ---------- NGON フォールバック --------------------------------
    idx = np.asarray([k for i in range(1, len(out)-1)
                         for k in (0, i, i+1)], np.int32)
    return v, idx


# ===== 6. マテリアル util ===============================================
_MM_ImageToMesh_mat_cache: dict[str, str] = {}
def get_mat(path: str) -> str:
    sg = _MM_ImageToMesh_mat_cache.get(path)
    if sg and cmds.objExists(sg): return sg
    _MM_ImageToMesh_mat_cache.pop(path, None)
    for f in cmds.ls(type="file"):
        try:
            if cmds.getAttr(f + ".fileTextureName", asString=True) == path:
                for lam in cmds.listConnections(f, type="lambert") or []:
                    for s in cmds.listConnections(lam, type="shadingEngine") or []:
                        _MM_ImageToMesh_mat_cache[path] = s; return s
        except Exception: pass
    fnode = cmds.shadingNode("file", asTexture=True, n="imgTex#")
    cmds.setAttr(f"{fnode}.fileTextureName", path, type="string")
    lam   = cmds.shadingNode("lambert", asShader=True, n="imgMat#")
    cmds.connectAttr(f"{fnode}.outColor", f"{lam}.color", f=True)
    if cmds.attributeQuery("outTransparency", node=fnode, exists=True):
        cmds.connectAttr(f"{fnode}.outTransparency", f"{lam}.transparency", f=True)
    sg = cmds.sets(r=True, noSurfaceShader=True, empty=True, n=f"{lam}SG")
    cmds.connectAttr(f"{lam}.outColor", f"{sg}.surfaceShader", f=True)
    _MM_ImageToMesh_mat_cache[path] = sg; return sg

# ===== 7. マスク・輪郭 ===================================================
_mask_cache: dict[tuple[str, int], tuple[np.ndarray, int, int, float]] = {}
def load_mask(path: str, margin: int, smooth: float = 0.0, ss_factor: int = 1,
              median: int = 0, closing: int = 0, p_range: tuple[int, int] = None):
    key = (path, margin, smooth, ss_factor, median, closing)
    if key in _mask_cache: return _mask_cache[key]
    
    p_min, p_max = p_range if p_range else (0, 0)
    p_step = (p_max - p_min) / 5.0
    p_cur = float(p_min)
    
    # 日本語パス対応の読み込み
    try:
        data = np.fromfile(path, np.uint8)
        img = cv2.imdecode(data, cv2.IMREAD_UNCHANGED)
    except Exception:
        img = None
    if img is None:
        raise RuntimeError("PNG を指定してください。")
    orig_h, orig_w = img.shape[:2]
    scale = 1.0
    if img.size > MAX_PIXELS:
        scale = .5
        img = cv2.resize(img, (int(img.shape[1] * scale),
                               int(img.shape[0] * scale)), interpolation=cv2.INTER_AREA)
    h, w = img.shape[:2]

    # 解像度倍率に合わせてリサイズ (INTER_CUBIC でサブピクセル精度を向上)
    used_ss = ss_factor
    if ss_factor > 1:
        # 4K制限: ss_factor適用後のサイズが4096を超えないように調整
        max_dim = max(w, h)
        if max_dim * ss_factor > 4096:
            used_ss = max(1, 4096 // max_dim)
        
        if used_ss > 1:
            p_cur += p_step; cmds.progressWindow(e=True, progress=int(p_cur), status=f"Resizing x{used_ss}...")
            up = cv2.resize(img, (w * used_ss, h * used_ss), interpolation=cv2.INTER_CUBIC)
        else:
            up = img
    else:
        up = img

    if up.shape[2] >= 4:
        alpha = up[:, :, 3]
        
        # 1. ノイズ除去 (Median Blur)
        if median > 0:
            p_cur += p_step; cmds.progressWindow(e=True, progress=int(p_cur), status="Denoising (Median)...")
            k_med = (median * 2 + 1)
            alpha = cv2.medianBlur(alpha, k_med)

        # 2. 隙間・穴埋め (Closing)
        if closing > 0:
            p_cur += p_step; cmds.progressWindow(e=True, progress=int(p_cur), status="Closing Holes...")
            k_size = closing * 2 + 1
            kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k_size, k_size))
            alpha = cv2.morphologyEx(alpha, cv2.MORPH_CLOSE, kernel)

        if smooth > 0:
            # ガウシアンブラによるスムージング処理
            p_cur += p_step; cmds.progressWindow(e=True, progress=int(p_cur), status="Smoothing...")
            k_size = int(smooth * ss_factor) * 2 + 1
            if k_size > 1:
                alpha = cv2.GaussianBlur(alpha, (k_size, k_size), 0)
                _, mask = cv2.threshold(alpha, 127, 255, cv2.THRESH_BINARY)
            else:
                mask = alpha
        else:
            _, mask = cv2.threshold(alpha, 127, 255, cv2.THRESH_BINARY)
    else:
        # アルファチャンネルがない場合は全体を不透明として扱うが、Closingなどは適用可能
        mask = np.full(up.shape[:2], 255, np.uint8)
        
    if margin:
        # マージン処理を分割してプログレスバーを更新
        total_margin = margin * ss_factor
        step_size = 5  # 5ピクセルごとに更新
        num_steps = max(1, (total_margin + step_size - 1) // step_size)
        
        # 1回あたりのカーネルサイズ (概算)
        # Dilateは繰り返し適用で広がるため、小さなカーネルを回す
        # ただし形状を保つため、正確には大きなカーネル1回が良いが、
        # プログレスバーのために分割する。MORPH_ELLIPSEなので完全な円にはならないが近似。
        # 単純に「ステップ数回繰り返す」アプローチをとる。
        
        # ※ 正確な形状維持のため、回数で割るのではなく、
        # 「イテレーション」機能を使うか、あるいは都度カーネル生成する。
        # OpenCVのdilateは iterations 引数があるが、コールバックがない。
        # なので、ループで回す。
        
        # step_size 分のカーネルを作成
        k_step = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (step_size * 2 + 1,) * 2)
        
        # 余り分調整...は複雑になるので、単純に step_size を num_steps 回適用し、
        # 合計が total_margin に近くなるように調整する
        # ここではユーザー体験優先で、step_size ずつ num_steps 回適用する
        
        # 正確さを期すなら:
        current_r = 0
        target_r = total_margin
        
        while current_r < target_r:
            next_step = min(step_size, target_r - current_r)
            if next_step <= 0: break
            
            k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (next_step * 2 + 1,) * 2)
            mask = cv2.dilate(mask, k)
            
            current_r += next_step
            
            # Progress 更新
            # p_cur はここまでで消費されているはず。残り (p_max - p_cur) を dilation に割り当て
            # しかし p_cur は前のブロックで increment されている。
            # 簡易的に、ここまでの p_cur から p_max までを補間
            ratio = current_r / target_r
            prog = p_cur + (p_max - p_cur) * ratio
            cmds.progressWindow(e=True, progress=int(prog), status=f"Dilating... {int(ratio*100)}%")

    _mask_cache[key] = (mask, w, h, scale, orig_w, orig_h, alpha if up.shape[2] >= 4 else None, used_ss); return _mask_cache[key]
def _signed_area(a: np.ndarray) -> float:
    if a.ndim != 2 or a.shape[0] < 3: return 0.0
    return 0.5 * float((a[:, 0] * np.roll(a[:, 1], -1) -
                        a[:, 1] * np.roll(a[:, 0], -1)).sum())
def clean_loop(loop: np.ndarray) -> np.ndarray:
    loop = np.asarray(loop, np.float32).reshape(-1, 2)
    diff = np.diff(loop, axis=0)
    keep = np.linalg.norm(diff, axis=1) > 1e-6
    cl   = np.vstack([loop[0], loop[1:][keep]])
    if np.allclose(cl[0], cl[-1]): cl = cl[:-1]
    if cl.shape[0] < 3:
        x, y = cl[:, 0], cl[:, 1]; pad = 1.0
        return np.array([[x.min() - pad, y.min() - pad],
                         [x.max() + pad, y.min() - pad],
                         [x.max() + pad, y.max() + pad],
                         [x.min() - pad, y.max() + pad]], np.float32)
    return cl

def smooth_contour_coordinates(loop: np.ndarray, size: int) -> np.ndarray:
    if size <= 0: return loop
    loop = np.asarray(loop, np.float32)
    n = len(loop)
    if n < 3: return loop

    pad = size * 2
    # Ensure we extend enough even if loop is small
    w_size = n + pad * 2
    # Create sufficient repeats to cover the padding window
    repeats = (w_size // n) + 2
    tiled = np.tile(loop, (repeats, 1))
    
    # We need to extract a center slice of length N, with PAD context on both sides
    # Center of tiled is roughly where we want to be.
    # Let's align such that we have loop in the middle.
    # tiled: [loop] [loop] ... [loop]
    # We want center one.
    
    mid_start = (len(tiled) - n) // 2
    # Ensure mid_start is a multiple of n to match phase if needed, 
    # but strictly we just need continuity.
    # Actually, simplistic tiling is fine because it's periodic.
    
    # Let's just construct exactly what we need: [pad_pre] + [loop] + [pad_post]
    # loop[-pad:] handles wrapping, but only if len(loop) > pad.
    # If len(loop) < pad, we need multiple wraps.
    
    # Safer approach:
    # Use take with wrap mode logic
    indices = np.arange(-pad, n + pad)
    extended = loop.take(indices, axis=0, mode='wrap')
    
    kernel = np.ones(size * 2 + 1) / (size * 2 + 1)
    
    smoothed_x = np.convolve(extended[:, 0], kernel, mode='same')
    smoothed_y = np.convolve(extended[:, 1], kernel, mode='same')
    
    # The 'same' mode centers the convolution.
    # extended has length: pad + n + pad.
    # convolve 'same' output has length: pad + n + pad.
    # We want the middle 'n' elements.
    
    res = np.column_stack([smoothed_x, smoothed_y])
    return res[pad:pad+n]

def refine_contour_alpha(loop: np.ndarray, alpha: np.ndarray, strength: float, ss_factor: int) -> np.ndarray:
    if strength <= 0 or alpha is None: return loop
    loop = np.asarray(loop, np.float32)
    h, w = alpha.shape[:2]
    refined = loop.copy()
    
    # 輪郭の各点において、法線方向にアルファ値をサンプリングして 127(0.5) の位置を探す
    for i in range(len(loop)):
        p = loop[i] * ss_factor
        prev_p = loop[i-1] * ss_factor
        next_p = loop[(i+1)%len(loop)] * ss_factor
        
        # 接線と法線
        tangent = next_p - prev_p
        norm = np.array([-tangent[1], tangent[0]], np.float32)
        mag = np.linalg.norm(norm)
        if mag < 1e-6: continue
        norm /= mag
        
        # 法線方向にサンプリング
        best_offset = 0.0
        min_diff = 999.0
        for off in np.linspace(-1.5, 1.5, 7):
            sample_p = p + norm * off
            ix, iy = int(sample_p[0]), int(sample_p[1])
            if 0 <= ix < w and 0 <= iy < h:
                val = float(alpha[iy, ix])
                diff = abs(val - 127.5)
                if diff < min_diff:
                    min_diff = diff
                    best_offset = off
        
        refined[i] = (p + norm * best_offset * strength) / ss_factor
        
    return refined

def islands(mask: np.ndarray, eps: float, ss_factor: int, alpha: np.ndarray = None, subpix: float = 0.0, smo: int = 0, p_range: tuple[int, int] = None):
    p_min, p_max = p_range if p_range else (0, 0)
    
    cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    outs = []
    total_cnts = len(cnts)
    for i, c in enumerate(cnts):
        if p_range and i % 50 == 0:
            prog = p_min + (p_max - p_min) * (i / total_cnts)
            cmds.progressWindow(e=True, progress=int(prog))
            
        if cv2.contourArea(c) < 3: continue
        p = cv2.approxPolyDP(c, eps * ss_factor, True)
        p = clean_loop(np.squeeze(p) / ss_factor)
        if p.shape[0] >= 3:
            if subpix > 0: p = refine_contour_alpha(p, alpha, subpix, ss_factor)
            if smo > 0: p = smooth_contour_coordinates(p, smo)
            outs.append(p)
    if p_range: cmds.progressWindow(e=True, progress=int(p_max))
    return outs
def extract_groups(mask: np.ndarray, eps: float, ss_factor: int, alpha: np.ndarray = None, subpix: float = 0.0, smo: int = 0, p_range: tuple[int, int] = None):
    p_min, p_max = p_range if p_range else (0, 0)

    cnts, hi = cv2.findContours(mask, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
    if not cnts or hi is None: raise RuntimeError("不透明領域がありません")
    hi = hi[0]
    ys, xs = np.where(mask)
    bbox     = float((np.ptp(xs) + 1) * (np.ptp(ys) + 1))
    min_area = bbox * _MIN_ISLAND_RATIO
    groups = []
    
    total_cnts = len(cnts)
    for i, c in enumerate(cnts):
        if p_range and i % 50 == 0:
            prog = p_min + (p_max - p_min) * (i / total_cnts)
            cmds.progressWindow(e=True, progress=int(prog))
            
        if hi[i][3] != -1 or cv2.contourArea(c) < min_area: continue
        o = clean_loop(np.squeeze(cv2.approxPolyDP(c, eps * ss_factor, True)) / ss_factor)
        if _signed_area(o) > 0: o = o[::-1]
        
        if subpix > 0: o = refine_contour_alpha(o, alpha, subpix, ss_factor)
        if smo > 0: o = smooth_contour_coordinates(o, smo)

        hole_loops = []
        ch = hi[i][2]
        while ch != -1:
            hc = cnts[ch]
            if cv2.contourArea(hc) >= min_area:
                h = clean_loop(np.squeeze(cv2.approxPolyDP(hc, eps * ss_factor, True)) / ss_factor)
                if _signed_area(h) < 0: h = h[::-1]
                if subpix > 0: h = refine_contour_alpha(h, alpha, subpix, ss_factor)
                if smo > 0: h = smooth_contour_coordinates(h, smo)
                hole_loops.append(h)
            ch = hi[ch][0]
        groups.append((o, hole_loops))
    if p_range: cmds.progressWindow(e=True, progress=int(p_max))
    return groups

# ===== 8. メッシュ生成 ===================================================
def _check_nan(v: np.ndarray, name: str) -> bool:
    if not np.isfinite(v).all():
        cmds.warning(f"Skipping {name}: Contains NaN or Inf vertices.")
        return False
    return True

def _check_indices(v: np.ndarray, idx: np.ndarray, name: str) -> bool:
    if len(idx) % 3 != 0:
        cmds.warning(f"Skipping {name}: Index count {len(idx)} is not divisible by 3.")
        return False
    if len(idx) == 0:
        return True
    if idx.min() < 0 or idx.max() >= len(v):
        cmds.warning(f"Skipping {name}: Indices out of bounds [0, {len(v)-1}]. Range: [{idx.min()}, {idx.max()}]")
        return False
    return True

def build_mesh(tag, v, idx, tex, w, h, cx=None, cy=None):
    if not _check_nan(v, tag): return None
    idx = np.asarray(idx, np.int32)
    if not _check_indices(v, idx, tag): return None
    
    _check_size(len(v), len(idx) // 3)
    if cx is None or cy is None:
        cx = .5 * (v[:, 0].min() + v[:, 0].max())
        cy = .5 * (v[:, 1].min() + v[:, 1].max())
    pts = [om2.MPoint(float(x - cx), float(cy - y), 0.0) for x, y in v]
    fn  = om2.MFnMesh()
    fn.create(pts, [3] * (len(idx) // 3), idx.tolist())
    trn = cmds.rename(cmds.listRelatives(fn.fullPathName(), p=True, f=True)[0], tag)
    fn.setUVs((v[:, 0] / w).tolist(), (1.0 - v[:, 1] / h).tolist())
    fn.assignUVs([3] * (len(idx) // 3), idx.tolist())
    if (sh := cmds.listRelatives(trn, shapes=True, f=True)):
        cmds.sets(sh[0], e=True, fe=get_mat(tex))
    cmds.polyNormal(trn, normalMode=0)
    return trn
def build_ngon(loop, parent, tex, w, h, cx, cy, i):
    name = f"island{i:02d}"
    if not _check_nan(loop, name): return 0
    _check_size(len(loop), 1) # Ngon also counts towards verts

    world = np.asarray([(float(x - cx), float(cy - y)) for x, y in loop], np.float32)
    if _signed_area(world) < 0: world, loop = world[::-1], loop[::-1]
    pts = [(float(x), float(y), 0.0) for x, y in world]
    msh = cmds.polyCreateFacet(p=pts, ch=False)[0]
    msh = cmds.rename(msh, f"island{i:02d}")
    cmds.parent(msh, parent)
    fn = om2.MFnMesh(om2.MSelectionList().add(msh).getDagPath(0))
    fn.setUVs((loop[:, 0] / w).tolist(), (1.0 - loop[:, 1] / h).tolist())
    fn.assignUVs([len(loop)], list(range(len(loop))))
    if (sh := cmds.listRelatives(msh, shapes=True, f=True)):
        cmds.sets(sh[0], e=True, fe=get_mat(tex))
    cmds.polyNormal(msh, normalMode=1)
    return loop.shape[0]

# ===== 9. Poisson 生成 ===================================================
# ===== 10. generate （三角形モード） =====================================
def generate(path: str, eps: float, margin: int,
             maxA: float, minimal: bool, mode: str,
             extra_points: np.ndarray = None, bbox_mode: bool = False,
             smooth: float = 0.0, ss_factor: int = 1,
             median: int = 0, closing: int = 0,
             subpix: float = 0.0, cnt_smo: int = 0):
    """
    extra_points: 追加ポイント群（配列）。C++コアは未対応のためPythonモードのみ有効。
    """

    if bbox_mode:
        cmds.progressWindow(e=True, status="Loading Mask...", progress=10)
        mask, w, h, scale, ow, oh, alpha, used_ss = load_mask(path, 0, 0.0, ss_factor, median, closing, p_range=(10, 50))
        cmds.progressWindow(e=True, status="Building Mesh...", progress=50)
        cx, cy = .5 * (ow - 1), .5 * (oh - 1)
        # スケールを考慮して頂点を生成
        v = np.array([[0, 0], [ow, 0], [ow, oh], [0, oh]], dtype=np.float32)
        idx = np.array([0, 1, 2, 0, 2, 3], dtype=np.int32)
        mesh = build_mesh("PreviewMesh", v, idx, path, ow, oh, cx, cy)
        cmds.progressWindow(e=True, progress=100)
        return mesh, 4, 2, scale, False, (ow, oh, used_ss)

    if extra_points is None:
        extra_points = np.empty((0,2), np.float32)
    for n in cmds.ls("PreviewMesh*", tr=True):
        cmds.delete(n)
    use_cpp = {"Auto": _USE_CPP, "C++": True, "Python": False}.get(mode, _USE_CPP)
    # スムーズ設定または高解像度スケール、あるいは高度なフィルタがある場合は Python モードを推奨
    if (smooth > 0 or ss_factor > 1 or median > 0 or closing > 0 or subpix > 0 or cnt_smo > 0) and use_cpp:
        # Warning は出さず、自動的に Python に切り替える
        use_cpp = False
    
    if mode == "C++" and not _USE_CPP:
        om.MGlobal.displayWarning("C++ コアが無いので Python 実装にフォールバック")
        use_cpp = False
    temp_path = None
    use_path, use_margin = path, margin
    if use_cpp and margin > 0:
        # 日本語パス対応の読み込み
        try:
            data = np.fromfile(path, np.uint8)
            img = cv2.imdecode(data, cv2.IMREAD_UNCHANGED)
        except Exception:
            img = None
        if img is None:
            raise RuntimeError("PNG を指定してください。")
        if img.shape[2] < 4:
            alpha = np.full(img.shape[:2], 255, np.uint8)
            img = np.dstack([img, alpha])
        else:
            alpha = img[:, :, 3]
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (margin * 2 + 1,) * 2)
        img[:, :, 3] = cv2.dilate(alpha, k)
        fd, tmp = tempfile.mkstemp(suffix=".png", dir=tempfile.gettempdir()); os.close(fd)
        # 日本語パス対応の書き出し
        try:
            _, buf = cv2.imencode(".png", img)
            buf.tofile(tmp)
        except Exception:
            cv2.imwrite(tmp, img)
        temp_path = tmp; use_path = tmp; use_margin = 0
    elif use_cpp and margin == 0:
        # 05_MM のような日本語パスを C++ コアが読み込めない場合があるため、一時的にコピー
        try:
            path.encode('ascii')
        except UnicodeEncodeError:
            fd, tmp = tempfile.mkstemp(suffix=".png", dir=tempfile.gettempdir()); os.close(fd)
            # 既存のファイルをコピー
            import shutil
            shutil.copy2(path, tmp)
            temp_path = tmp; use_path = tmp; use_margin = 0
    if use_cpp:
        try:
            return _process_cpp_logic(path, eps, margin, maxA, minimal, temp_path)
        except Exception:
            om.MGlobal.displayWarning("C++ 失敗 → Python")
            if temp_path and os.path.exists(temp_path): os.remove(temp_path)

    return _process_python_logic(path, eps, margin, smooth, ss_factor, median, closing, subpix, cnt_smo, minimal, extra_points)


def _process_cpp_logic(path: str, eps: float, margin: int, maxA: float, minimal: bool, temp_path: str | None):
    # generate関数から分離されたC++ロジック
    use_path, use_margin = (temp_path, 0) if temp_path else (path, margin)
    try:
        cmds.progressWindow(e=True, status="C++ Processing...", progress=20)
        if minimal:
            d = mm_itm_core.islands(use_path, eps, use_margin)
            cmds.progressWindow(e=True, status="Building Mesh...", progress=60)
            loops = [np.asarray(l, np.float32).reshape(-1, 2) for l in d["loops"]]
            w, h, scale = d["w"], d["h"], d["scale"]; cx, cy = .5*(w-1), .5*(h-1)
            grp = cmds.group(em=True, n="PreviewMesh"); vtot = 0
            
            total_loops = len(loops)
            for i, loop in enumerate(loops, 1):
                if i % 10 == 0:
                     cmds.progressWindow(e=True, progress=60 + int(30 * i / total_loops))
                vtot += build_ngon(loop, grp, path, w, h, cx, cy, i)
            if temp_path and os.path.exists(temp_path): os.remove(temp_path)
            cmds.progressWindow(e=True, progress=100)
            return grp, vtot, len(loops), scale, True, (w, h, 1)
        
        d = mm_itm_core.triangulate_png(use_path, eps, use_margin, maxA)
        cmds.progressWindow(e=True, status="Building Mesh...", progress=60)
        w, h, scale = d["w"], d["h"], d["scale"]; cx, cy = .5*(w-1), .5*(h-1)
        grp = cmds.group(em=True, n="PreviewMesh"); tv = tf = 0
        
        groups = d["groups"]
        total_groups = len(groups)
        for i, g in enumerate(groups, 1):
            if i % 10 == 0:
                cmds.progressWindow(e=True, progress=60 + int(30 * i / total_groups))
            v   = np.asarray(g["v"], np.float32).reshape(-1, 2)
            idx = np.asarray(g["idx"], np.int32)
            msh = build_mesh(f"islandTri{i:02d}", v, idx, path, w, h, cx, cy)
            cmds.parent(msh, grp); tv += len(v); tf += len(idx)//3
        if temp_path and os.path.exists(temp_path): os.remove(temp_path)
        cmds.progressWindow(e=True, progress=100)
        return grp, tv, tf, scale, True, (w, h, 1)
    except Exception:
        if temp_path and os.path.exists(temp_path): os.remove(temp_path)
        raise


def _process_python_logic(path, eps, margin, smooth, ss_factor, median, closing, subpix, cnt_smo, minimal, extra_points):
    # generate関数から分離されたPythonロジック
    cmds.progressWindow(e=True, status="Loading Mask & Preprocessing...", progress=10)
    # 重たい画像処理に 10% -> 60% を割り当て
    mask, w, h, scale, ow, oh, alpha, used_ss = load_mask(path, margin, smooth, ss_factor, median, closing, p_range=(10, 60)); cx, cy = .5*(ow-1), .5*(oh-1)
    inv_sc = 1.0 / scale
    
    if minimal:
        cmds.progressWindow(e=True, status="Finding Islands...", progress=60)
        loops = islands(mask, eps, used_ss, alpha, subpix, cnt_smo, p_range=(60, 80))
        
        cmds.progressWindow(e=True, status="Building Mesh...", progress=80)
        grp = cmds.group(em=True, n="PreviewMesh"); vtot = 0
        total_loops = len(loops)
        for i, loop in enumerate(loops, 1):
            if i % 10 == 0:
                # 80% -> 100%
                cmds.progressWindow(e=True, progress=80 + int(20 * i / total_loops))
            loop_orig = loop * inv_sc
            vtot += build_ngon(loop_orig, grp, path, ow, oh, cx, cy, i)
        cmds.progressWindow(e=True, progress=100)
        return grp, vtot, len(loops), scale, False, (ow, oh, used_ss)
    
    cmds.progressWindow(e=True, status="Extracting Groups...", progress=60)
    groups = extract_groups(mask, eps, used_ss, alpha, subpix, cnt_smo, p_range=(60, 80))
    
    if len(groups) == 1:
        cmds.progressWindow(e=True, status="Triangulating...", progress=80)
        v, holes = groups[0]
        v_orig = v * inv_sc
        holes_orig = [h * inv_sc for h in holes]
        v_final, idx = triangulate_full(v_orig, holes_orig, extra_points, ow*oh)
        mesh = build_mesh("PreviewMesh", v_final, idx, path, ow, oh, cx, cy)
        cmds.progressWindow(e=True, progress=100)
        return mesh, len(v_final), len(idx)//3, scale, False, (ow, oh, used_ss)
    
    cmds.progressWindow(e=True, status="Building Mesh (Multiple Islands)...", progress=80)
    grp = cmds.group(em=True, n="PreviewMesh"); tv = tf = 0
    total_groups = len(groups)
    for i, (v, holes) in enumerate(groups, 1):
        if i % 5 == 0:
             # 80% -> 100%
             cmds.progressWindow(e=True, progress=80 + int(20 * i / total_groups))
        v_orig = v * inv_sc
        holes_orig = [h * inv_sc for h in holes]
        v_final, idx = triangulate_full(v_orig, holes_orig, extra_points, ow*oh)
        msh = build_mesh(f"islandTri{i:02d}", v_final, idx, path, ow, oh, cx, cy)
        cmds.parent(msh, grp); tv += len(v_final); tf += len(idx)//3
    cmds.progressWindow(e=True, progress=100)
    return grp, tv, tf, scale, False, (ow, oh, used_ss)


# ===== 11. 集計 util =====================================================
def _count_mesh_components(root: str) -> tuple[int, int, int]:
    if not cmds.objExists(root): return 0, 0, 0
    shapes = set(cmds.listRelatives(root, ad=True, type="mesh", f=True) or [])
    v = f = t = 0
    for sh in shapes:
        v += cmds.polyEvaluate(sh, v=True)
        f += cmds.polyEvaluate(sh, f=True)
        t += cmds.polyEvaluate(sh, t=True)
    return v, f, t

# ===== 12. UI ============================================================
class UI:
    WIN = "MM_ImageToMesh_Window"
    def __init__(self):
        self.prev = None
        self.update_timer = None
        self.is_processing = False
        if QtCore:
            self.update_timer = QtCore.QTimer()
            self.update_timer.setSingleShot(True)
            self.update_timer.setInterval(600) # 600ms debounce (Increased from 200ms)
            self.update_timer.timeout.connect(self._perform_update)
            
        if cmds.window(self.WIN, exists=True):
            cmds.deleteUI(self.WIN)
        self.build()

    def build(self):
        cmds.window(self.WIN, title="MM_ImageToMesh", wh=(270, 360), sizeable=True)
        cmds.menuBarLayout()
        cmds.menu(l="編集"); cmds.menuItem(l="リセット", c=self.reset)
        cmds.menu(l="ヘルプ"); cmds.menuItem(l="ヘルプ", c=lambda *_:
            webbrowser.open("https://kurosiro0112.github.io/MM_ImageToMesh_wiki/guide/usage.html"))
        cmds.setParent("..")
        
        self.main_col = cmds.columnLayout(adj=True, rs=4)
        cmds.text(l="PNG 画像の読み込み", al="left")
        cmds.rowLayout(nc=2, cw2=(250, 40), adjustableColumn=1)
        self.fld = cmds.textField(w=250)
        cmds.button(l="...", w=30, c=self.browse)
        cmds.setParent("..")

        self.lbl_res = cmds.text(l="Resolution: - x -", al="left")

        cmds.rowLayout(nc=3, cw3=(100, 40, 10), adjustableColumn=3)
        self.chk = cmds.checkBox(l="穴開き対応", v=False, cc=self.on_holes_toggle)
        cmds.text(l="モード", al="left")
        self.mode = cmds.optionMenu(w=60)
        [cmds.menuItem(l=m) for m in ("Auto", "C++", "Python")]
        cmds.setParent("..")

        self.chk_bbox = cmds.checkBox(l="画像のバウンディングボックスで作成", v=False, cc=self.update)

        self.eps = cmds.floatSliderGrp(l="簡略化", f=True, min=0.2, max=10,
                                       fmn=0, fmx=50, v=2, s=0.5,
                                       cw3=(110, 50, 10), cc=self.update)

        self.res_scale = cmds.intSliderGrp(l="解像度のスケール", f=True, min=1, max=10, 
                                           v=1, cw3=(110, 50, 10),
                                           cc=self.update)

        self.med = cmds.intSliderGrp(l="ノイズ除去", f=True, min=0, max=10, 
                                     v=0, cw3=(110, 50, 10),
                                     cc=self.update)

        self.subpix = cmds.floatSliderGrp(l="サブピクセル補完", f=True, min=0, max=1, 
                                          v=0, step=0.1, cw3=(110, 50, 10),
                                          cc=self.update)

        self.smo = cmds.floatSliderGrp(l="スムーズ化", f=True, min=0, max=20,
                                       fmx=100, v=0, s=0.1,
                                       cw3=(110, 50, 10), cc=self.update)

        self.cnt_smo = cmds.intSliderGrp(l="輪郭スムーズ", f=True, min=0, max=10, 
                                         v=0, cw3=(110, 50, 10),
                                         cc=self.update)

        self.cls = cmds.intSliderGrp(l="隙間・穴埋め", f=True, min=0, max=10, 
                                     v=0, cw3=(110, 50, 10),
                                     cc=self.update)

        self.mar = cmds.intSliderGrp(l="マージン", f=True, min=0, max=100,
                                     fmx=256, v=0, cw3=(110, 50, 10),
                                     cc=self.update)



        # cmds.separator(h=5, st="none")
        # cmds.separator(h=5, st="none")
        self.info = cmds.text(l="Verts:0  Faces:0  Tris:0\n[Using: ---]")
        cmds.button(l="メッシュを確定", h=30, c=self.finalize)
        cmds.separator(h=10, st="none")
        self.tess_frame = cmds.frameLayout(l="テッセレーション", cll=True, cl=True, mh=5)
        cmds.columnLayout(adj=True, rs=2)
        cmds.button(l="再メッシュ（既にあれば値を取得）", h=20, c=self.remesh_selected)
        # スライダー追加
        self.edge_slider = cmds.floatSliderGrp(l="最大エッジ長", field=True, min=0.1, max=200, v=100, cw3=(90, 50, 10), cc=self.on_remesh_param_changed)
        self.cons_slider = cmds.floatSliderGrp(l="集約しきい値", field=True, min=0, max=100, v=20, cw3=(90, 50, 10), cc=self.on_remesh_param_changed)
        self.smooth_slider = cmds.floatSliderGrp(l="スムーズの強さ", field=True, min=0, max=100, fmn=0, fmx=1, v=0, step=0.01, cw3=(90, 50, 10), cc=self.on_remesh_param_changed)
        cmds.setParent("..") # end columnLayout
        cmds.setParent("..") # end frameLayout
        cmds.showWindow(self.WIN)
        # UI構築時に選択オブジェクトのremesh値を反映
        self.update_remesh_sliders_from_selection()

    # ---------- callbacks -------------------------------------------------
    def browse(self, *_):
        p = cmds.fileDialog2(ff="*.png", fm=1, ds=2)
        if p:
            cmds.textField(self.fld, e=True, tx=p[0]); self.update()

    def on_holes_toggle(self, *_):
        self.update()


    def update(self, *_):
        if self.update_timer:
            self.update_timer.start()
        else:
            self._perform_update()

    def _perform_update(self, *_):
        if self.is_processing:
            if self.update_timer:
                self.update_timer.start() # Reschedule
            return


        self.is_processing = True
        
        # Memory Protection: Disable Undo during preview generation
        cmds.undoInfo(stateWithoutFlush=False)
        
        try:
            if cmds.layout(self.main_col, q=True, exists=True):
                cmds.layout(self.main_col, e=True, enable=False)
            
            img = cmds.textField(self.fld, q=True, tx=True).strip()
            # 画像パスが変わった場合のみキャッシュをクリア
            if getattr(self, '_last_img', None) != img:
                global _MM_ImageToMesh_mat_cache
                _MM_ImageToMesh_mat_cache.clear()
                self._last_img = img

            img = cmds.textField(self.fld, q=True, tx=True).strip()
            if not img: 
                cmds.text(self.info, e=True, l="Verts:0  Faces:0  Tris:0\n[Using: ---]")
                cmds.text(self.lbl_res, e=True, l="Resolution: - x -")
                self.update_remesh_sliders_from_selection()
                return
            self.reset_prev()
            eps = cmds.floatSliderGrp(self.eps, q=True, v=True)
            smo = cmds.floatSliderGrp(self.smo, q=True, v=True)
            mar = cmds.intSliderGrp(self.mar, q=True, v=True)
            res = cmds.intSliderGrp(self.res_scale, q=True, v=True)
            med = cmds.intSliderGrp(self.med, q=True, v=True)
            cls = cmds.intSliderGrp(self.cls, q=True, v=True)
            spx = cmds.floatSliderGrp(self.subpix, q=True, v=True)
            csm = cmds.intSliderGrp(self.cnt_smo, q=True, v=True)
            holes_on = cmds.checkBox(self.chk, q=True, v=True)
            bbox_on  = cmds.checkBox(self.chk_bbox, q=True, v=True)
            mode     = cmds.optionMenu(self.mode, q=True, v=True)
            
            cmds.waitCursor(state=True)
            # プログレスバー開始
            cmds.progressWindow(t="Processing...", status="Start", isInterruptable=False, min=0, max=100)
            try:
                minimal = not holes_on
                mesh, vn, tris, sc, used_cpp, res_info = generate(img, eps, mar,
                                                        8000.0, minimal, mode,
                                                        bbox_mode=bbox_on,
                                                        smooth=smo,
                                                        ss_factor=res,
                                                        median=med,
                                                        closing=cls,
                                                        subpix=spx,
                                                        cnt_smo=csm)
                
                # Resolution Info Update
                # Resolution Info Update
                cur_w, cur_h, cur_ss = res_info
                
                # Default text for scale 1
                msg_res = f"{cur_w}x{cur_h}"
                
                if cur_ss > 1:
                    # Scaled: "1024x1024 -> 2048x2048"
                    msg_res += f" -> {cur_w*cur_ss}x{cur_h*cur_ss}"
                    
                if cur_ss < res:
                    # Clamped: "1024x1024 -> 2048x2048 [4K Limited]"
                    msg_res += " [4K Limited]"
                    
                cmds.text(self.lbl_res, e=True, l=f"Resolution: {msg_res}")

                cmds.text(self.info, e=True,
                        l=f"Verts:{vn}  Faces:{tris}  Tris:{tris}\n[Using: {'C++' if used_cpp else 'Python'}]")

                cmds.select(mesh, r=True)
                self.prev = mesh  # プレビュー用のみ
            except Exception as e:
                cmds.warning(str(e))
                cmds.text(self.info, e=True, l="Verts:0  Faces:0  Tris:0\n[Error]")
                cmds.text(self.lbl_res, e=True, l="Resolution: - x -")
            finally:
                cmds.progressWindow(endProgress=True)
                cmds.waitCursor(state=False)

            self.update_remesh_sliders_from_selection()
        
        finally:
            if cmds.layout(self.main_col, q=True, exists=True):
                cmds.layout(self.main_col, e=True, enable=True)
            cmds.undoInfo(stateWithoutFlush=True)
            gc.collect() # Force garbage collection
            self.is_processing = False



    def reset_prev(self):
        # プレビュー用（PreviewMeshグループ）のみ削除
        if self.prev and cmds.objExists(self.prev):
            cmds.delete(self.prev)
            self.prev = None

    def reset(self, *_):
        self.reset_prev()
        cmds.textField(self.fld, e=True, tx="")
        cmds.floatSliderGrp(self.eps, e=True, v=2)
        cmds.floatSliderGrp(self.smo, e=True, v=0)
        cmds.intSliderGrp(self.res_scale, e=True, v=1)
        cmds.intSliderGrp(self.med, e=True, v=0)
        cmds.intSliderGrp(self.cls, e=True, v=0)
        cmds.floatSliderGrp(self.subpix, e=True, v=0)
        cmds.intSliderGrp(self.cnt_smo, e=True, v=0)
        cmds.intSliderGrp(self.mar, e=True, v=0)
        cmds.checkBox(self.chk, e=True, v=False)
        cmds.checkBox(self.chk_bbox, e=True, v=False)
        cmds.optionMenu(self.mode, e=True, sl=1)
        cmds.text(self.info, e=True, l="Verts:0  Faces:0  Tris:0\n[Using: ---]")
        # テッセレーションスライダーもデフォルト値に戻す
        cmds.floatSliderGrp(self.edge_slider, e=True, v=100)
        cmds.floatSliderGrp(self.cons_slider, e=True, v=20)
        cmds.floatSliderGrp(self.smooth_slider, e=True, v=0)

    def finalize(self, *_):
        if not self.prev or not cmds.objExists(self.prev):
            cmds.warning("プレビューがありません"); return
        
        # Undo チャンク開始
        cmds.undoInfo(openChunk=True, chunkName="MM_ImageToMesh_Finalize")
        try:
            base = os.path.splitext(os.path.basename(cmds.textField(
                   self.fld, q=True, tx=True)))[0] or "Mesh"
            
            # PreviewMesh配下の全メッシュを取得
            meshes = cmds.listRelatives(self.prev, ad=True, type="mesh", f=True) or []
            transforms = cmds.listRelatives(meshes, p=True, f=True) or []
            if isinstance(transforms, str):
                transforms = [transforms]
            transforms = list(set(transforms))
            
            if not transforms:
                cmds.warning("結合対象のメッシュがありません")
                return

            if len(transforms) > 1:
                # 複数メッシュを結合
                united = cmds.polyUnite(transforms, ch=False, n=base)[0]
                for t in transforms:
                    if cmds.objExists(t):
                        cmds.delete(t)
                if cmds.objExists(self.prev):
                    cmds.delete(self.prev)
                cmds.select(united, r=True)
                om.MGlobal.displayInfo(f"Combined Mesh: {united}")
                self.prev = None
            else:
                # 単一メッシュの場合もリネーム
                renamed = cmds.rename(transforms[0], base)
                parented = cmds.parent(renamed, world=True)
                node_name = parented[0] if isinstance(parented, (list, tuple)) else (parented or renamed)
                node_name = node_name.split('|')[-1]
                if cmds.objExists(self.prev):
                    cmds.delete(self.prev)
                cmds.select(node_name, r=True)
                om.MGlobal.displayInfo(f"Created Mesh: {node_name}")
                self.prev = None
        except Exception as e:
            cmds.warning(f"確定失敗: {e}")
        finally:
            # Undo チャンク終了
            cmds.undoInfo(closeChunk=True)

    def remesh_selected(self, *_):
        sels = cmds.ls(sl=True, long=True, type="transform")
        if not sels:
            cmds.warning("再メッシュ対象を選択してください")
            return
        for obj in sels:
            shapes = cmds.listRelatives(obj, s=True, type="mesh", f=True) or []
            if not shapes:
                cmds.warning(f"{obj} はメッシュではありません")
                continue
            # polyRemeshヒストリーがあるか判定
            has_remesh = False
            for shape in shapes:
                hists = cmds.listHistory(shape, f=True) or []
                for node in hists:
                    if cmds.nodeType(node) == "polyRemesh":
                        has_remesh = True
                        break
                if has_remesh:
                    break
            if has_remesh:
                # 既にpolyRemeshヒストリーがある場合は値をUIに反映のみ
                self.update_remesh_sliders_from_selection()
                om.MGlobal.displayInfo(f"既存のpolyRemeshヒストリー値を取得: {obj}")
            else:
                try:
                    mel.eval('PolyRemesh;')
                    om.MGlobal.displayInfo(f"再メッシュ実行: {obj}")
                except Exception as e:
                    cmds.warning(f"再メッシュ失敗: {obj} : {e}")
                self.update_remesh_sliders_from_selection()

    def set_remesh_history_params(self, obj, edge, cons, smooth):
        # objのpolyRemeshヒストリーを探して値をセット
        shapes = cmds.listRelatives(obj, s=True, type="mesh", f=True) or []
        for shape in shapes:
            hists = cmds.listHistory(shape, f=True) or []
            for node in hists:
                if cmds.nodeType(node) == "polyRemesh":
                    try:
                        if edge is not None:
                            cmds.setAttr(f"{node}.maxEdgeLength", edge)
                        if cmds.attributeQuery("collapseThreshold", node=node, exists=True):
                            cmds.setAttr(f"{node}.collapseThreshold", cons)
                        if cmds.attributeQuery("smoothStrength", node=node, exists=True):
                            cmds.setAttr(f"{node}.smoothStrength", smooth)
                    except Exception:
                        pass

    def update_remesh_sliders_from_selection(self, *_):
        sels = cmds.ls(sl=True, long=True, type="transform")
        if not sels:
            return
        obj = sels[0]
        shapes = cmds.listRelatives(obj, s=True, type="mesh", f=True) or []
        for shape in shapes:
            hists = cmds.listHistory(shape, f=True) or []
            for node in hists:
                if cmds.nodeType(node) == "polyRemesh":
                    # ヒストリーから値を取得しスライダーに反映
                    try:
                        edge = cmds.getAttr(f"{node}.maxEdgeLength")
                        cmds.floatSliderGrp(self.edge_slider, e=True, v=edge)
                    except Exception:
                        pass
                    try:
                        if cmds.attributeQuery("collapseThreshold", node=node, exists=True):
                            cons = cmds.getAttr(f"{node}.collapseThreshold")
                            cmds.floatSliderGrp(self.cons_slider, e=True, v=cons)
                    except Exception:
                        pass
                    try:
                        if cmds.attributeQuery("smoothStrength", node=node, exists=True):
                            smooth = cmds.getAttr(f"{node}.smoothStrength")
                            cmds.floatSliderGrp(self.smooth_slider, e=True, v=smooth)
                    except Exception:
                        pass
                    return  # 最初のpolyRemeshノードのみ反映

    def on_remesh_param_changed(self, *_):
        # スライダー変更時に選択メッシュのpolyRemeshヒストリーを更新
        sels = cmds.ls(sl=True, long=True, type="transform")
        if not sels:
            return
        obj = sels[0]
        edge = max(0.001, cmds.floatSliderGrp(self.edge_slider, q=True, v=True))
        cons = cmds.floatSliderGrp(self.cons_slider, q=True, v=True)
        smooth = cmds.floatSliderGrp(self.smooth_slider, q=True, v=True)
        self.set_remesh_history_params(obj, edge, cons, smooth)


# ===== 13. entry ========================================================
def main(): UI()
if __name__ == "__main__": main()
