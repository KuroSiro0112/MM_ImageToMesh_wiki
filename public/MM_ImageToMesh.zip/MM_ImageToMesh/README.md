# MM_ImageToMesh

## 概要

**MM_ImageToMesh** は、Maya 用のツールです。  
PNG 画像からメッシュを自動生成します。アルファ付きが推奨ですが、アルファなしの PNG は全ピクセルを不透明として扱います。

## 起動コマンド
```python
#------------------------------------------------------------------------
# 起動コマンド例
# 以下のパスを実際にファイルを置いた場所に合わせて書き換えてください。
# 例: r"C:\Users\YourName\Documents\maya\scripts\MM_ImageToMesh"

import sys
import importlib
import os

# ツールフォルダのパスを指定
script_path = r"C:\Path\To\MM_ImageToMesh"

if script_path not in sys.path:
    sys.path.insert(0, script_path)

import MM_ImageToMesh
importlib.reload(MM_ImageToMesh)
MM_ImageToMesh.main()
#------------------------------------------------------------------------
```

## 参考
https://github.com/Pullusb/Tesselate_texture_plane

---
## 仕様
- Maya2024でのみ動作確認済み  
（2025以上はPythonのバージョンが違うため動作しない可能性高い）
- 日本語を含む画像パスを正式にサポートしています
