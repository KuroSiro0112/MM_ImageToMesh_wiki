# MM_ImageToMesh Wiki 公開スクリプト

$wikiSrc = "C:\Users\cluster\Documents\maya\scripts\00_MM\MM_ImageToMesh\wiki"
$wikiDest = "C:\Users\cluster\Documents\maya\scripts\00_MM\MM_ImageToMesh_wiki"

if (-not (Test-Path $wikiSrc)) {
    Write-Error "Source directory not found: $wikiSrc"
    exit
}

if (-not (Test-Path $wikiDest)) {
    Write-Error "Destination directory not found: $wikiDest"
    exit
}

Write-Host "Syncing Wiki data..." -ForegroundColor Cyan

# 既存のファイルを削除 ( .git は残す )
Get-ChildItem -Path $wikiDest -Exclude ".git" | Remove-Item -Recurse -Force

# ファイルをコピー
Copy-Item -Path "$wikiSrc\*" -Destination $wikiDest -Recurse -Force

# 不要なフォルダを除外 (node_modulesなど)
$excludeDirs = @("node_modules", ".git")
foreach ($dir in $excludeDirs) {
    if (Test-Path "$wikiDest\$dir") {
        Remove-Item -Path "$wikiDest\$dir" -Recurse -Force
    }
}

Write-Host "Files copied. Pushing to GitHub..." -ForegroundColor Cyan

# Git操作
Push-Location $wikiDest
if (-not (Test-Path ".git")) {
    Write-Host "Initializing Git repository..." -ForegroundColor Yellow
    git init
    git remote add origin https://github.com/KuroSiro0112/MM_ImageToMesh_wiki.git
}
git checkout -B main
git add -A
git commit -m "Update Wiki: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
git push -u origin main -f
Pop-Location

Write-Host "Wiki publish complete!" -ForegroundColor Green
